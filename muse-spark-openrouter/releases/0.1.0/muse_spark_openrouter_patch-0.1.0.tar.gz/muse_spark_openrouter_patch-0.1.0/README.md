# Muse Spark OpenRouter Patch

This package makes Meta Muse Spark work as a Codex model through OpenRouter.
It fixes two failure modes without embedding an API key in source or Codex
configuration:

1. Codex can inherit a stale `OPENROUTER_API_KEY`, causing OpenRouter to return
   `401 User not found` even after a new key was entered elsewhere.
2. Muse Spark rejects Responses API function names longer than 64 characters.
   Codex namespaces are flattened with a separator, so two individually valid
   namespace/tool components can become a 66-character provider name and make
   an otherwise-valid request fail before inference with HTTP 400.

The local proxy deterministically shortens overlong names on requests and
restores their original names on JSON and SSE responses. Authorization headers
are forwarded but never logged. The key is stored in a mode-`0600` file and is
supplied to Codex through its supported `auth.command` mechanism.

## Install

The simplest installation is the Bash installer. It installs only for the
current user and prompts for the OpenRouter key without echoing it:

```bash
curl -LsSf https://session-migrate.github.io/muse-spark-openrouter/install.sh | sh
```

To install the commands without changing Codex yet, or from a local release
checkout:

```bash
curl -LsSf https://session-migrate.github.io/muse-spark-openrouter/install.sh | sh -s -- --install-only
sh install.sh --install-only
```

The equivalent manual installation is:

```bash
uv tool install ./dist/muse_spark_openrouter_patch-0.1.0-py3-none-any.whl
muse-spark-openrouter setup --set-default
muse-spark-openrouter doctor --live
```

`setup` prompts without echo. For automation, pass the key on standard input so
it does not appear in shell history or the process list:

```bash
printf '%s\n' "$OPENROUTER_API_KEY" | muse-spark-openrouter setup --key-stdin
```

Run Codex with the installed profile:

```bash
codex-muse
codex-muse exec --ephemeral "Reply with exactly OK"
```

The default model is `meta/muse-spark-1.2`. Choose another OpenRouter Muse
Spark slug during setup with `--model`.

## Docker

The proxy contains no credential and can run read-only:

```bash
docker compose up -d --build
```

Point an OpenAI Responses-compatible client at
`http://127.0.0.1:8787/api/v1` and continue sending its OpenRouter bearer token
normally.

## Security notes

- The proxy binds to `127.0.0.1` by default.
- It does not persist, print, or log authorization headers or request bodies.
- The credential lives at
  `${XDG_CONFIG_HOME:-~/.config}/muse-spark-openrouter/credential` with mode
  `0600`.
- Rotate any API key that has been pasted into a chat, issue, or terminal log.

## Development and release

```bash
uv run --with pytest pytest
uv build
docker build -t muse-spark-openrouter-patch:0.1.0 .
```

Artifacts are pure Python wheels/source archives and work on Linux, macOS, and
Windows. The systemd user-service setup is Linux-specific; other platforms use
the launch-on-demand `codex-muse` wrapper.
