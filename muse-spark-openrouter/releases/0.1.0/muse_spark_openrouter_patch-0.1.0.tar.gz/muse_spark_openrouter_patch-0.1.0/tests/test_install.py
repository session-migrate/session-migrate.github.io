import unittest

from muse_spark_openrouter.install import (
    MANAGED_BEGIN,
    MANAGED_END,
    replace_managed_block,
)


class ManagedBlockTests(unittest.TestCase):
    def test_replaces_existing_block_idempotently(self):
        source = f"before\n{MANAGED_BEGIN}\nold\n{MANAGED_END}\nafter\n"
        block = f"{MANAGED_BEGIN}\nnew\n{MANAGED_END}"
        once = replace_managed_block(source, block)
        twice = replace_managed_block(once, block)
        self.assertEqual(once, twice)
        self.assertNotIn("old", once)
        self.assertIn("new", once)


if __name__ == "__main__":
    unittest.main()
