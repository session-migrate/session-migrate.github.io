"""Stateless tool-name rewriting for providers with a 64-character limit."""

from __future__ import annotations

import hashlib
from copy import deepcopy
from typing import Any

MAX_TOOL_NAME_LENGTH = 64
NAMESPACE_SEPARATOR_LENGTH = 2
_HASH_LENGTH = 12


def alias_tool_name(name: str, max_length: int = MAX_TOOL_NAME_LENGTH) -> str:
    """Return a deterministic, collision-resistant provider-safe tool name."""
    if max_length < 1:
        raise ValueError("max_length must be positive")
    if len(name) <= max_length:
        return name
    digest = hashlib.sha256(name.encode("utf-8")).hexdigest()[:_HASH_LENGTH]
    if max_length <= _HASH_LENGTH:
        return digest[:max_length]
    prefix_length = max_length - _HASH_LENGTH - 1
    return f"{name[:prefix_length]}_{digest}"


def collect_tool_name_map(payload: Any) -> dict[str, str]:
    """Collect long tool names from a Responses API payload.

    Codex can send both flat function tools and namespaced/nested tools. Walk
    only the top-level ``tools`` subtree so unrelated names in conversation
    input or metadata are not mistaken for tool declarations.
    """
    if not isinstance(payload, dict):
        return {}

    tools = payload.get("tools")
    if not isinstance(tools, list):
        return {}

    limits: dict[str, int] = {}

    def record_limit(name: str, limit: int) -> None:
        limit = max(1, limit)
        if len(name) <= limit:
            return
        previous = limits.get(name)
        limits[name] = min(previous, limit) if previous is not None else limit

    def visit_declaration(value: Any, prefix_length: int = 0) -> None:
        if isinstance(value, list):
            for item in value:
                visit_declaration(item, prefix_length)
            return
        if not isinstance(value, dict):
            return

        name = value.get("name")
        effective_prefix = prefix_length
        if isinstance(name, str):
            component_limit = MAX_TOOL_NAME_LENGTH - prefix_length
            record_limit(name, component_limit)
            effective_length = min(len(name), max(1, component_limit))
            effective_prefix = (
                prefix_length + effective_length + NAMESPACE_SEPARATOR_LENGTH
            )

        children = value.get("tools")
        if isinstance(children, list):
            visit_declaration(children, effective_prefix)

        # Some compatible clients wrap a function declaration one level down.
        function = value.get("function")
        if isinstance(function, dict):
            visit_declaration(function, prefix_length)

    visit_declaration(tools)

    # Catch any other flat/custom declaration shape within the tools subtree.
    pending: list[Any] = list(tools)
    while pending:
        value = pending.pop()
        if isinstance(value, list):
            pending.extend(value)
        elif isinstance(value, dict):
            pending.extend(value.values())
            name = value.get("name")
            if isinstance(name, str):
                record_limit(name, MAX_TOOL_NAME_LENGTH)

    mapping: dict[str, str] = {}
    used_aliases: dict[str, str] = {}
    for name, limit in limits.items():
        alias = alias_tool_name(name, limit)
        previous = used_aliases.get(alias)
        if previous is not None and previous != name:
            # This is extraordinarily unlikely, but retain determinism while
            # avoiding a silent collision if it ever occurs.
            salt = 1
            while alias in used_aliases and used_aliases[alias] != name:
                salted = f"{name}:{salt}"
                alias = alias_tool_name(salted, limit)
                salt += 1
        mapping[name] = alias
        used_aliases[alias] = name
    return mapping


def _rewrite_name_fields(value: Any, mapping: dict[str, str]) -> Any:
    if isinstance(value, list):
        return [_rewrite_name_fields(item, mapping) for item in value]
    if not isinstance(value, dict):
        return value

    rewritten: dict[str, Any] = {}
    for key, item in value.items():
        if key == "name" and isinstance(item, str) and item in mapping:
            rewritten[key] = mapping[item]
        else:
            rewritten[key] = _rewrite_name_fields(item, mapping)
    return rewritten


def rewrite_request(payload: Any) -> tuple[Any, dict[str, str]]:
    """Rewrite overlong tool names and return alias-to-original response map."""
    mapping = collect_tool_name_map(payload)
    if not mapping:
        return payload, {}
    rewritten = _rewrite_name_fields(deepcopy(payload), mapping)
    return rewritten, {alias: original for original, alias in mapping.items()}


def rewrite_response(payload: Any, alias_to_original: dict[str, str]) -> Any:
    """Restore Codex's original tool names in provider responses."""
    if not alias_to_original:
        return payload
    return _rewrite_name_fields(payload, alias_to_original)
