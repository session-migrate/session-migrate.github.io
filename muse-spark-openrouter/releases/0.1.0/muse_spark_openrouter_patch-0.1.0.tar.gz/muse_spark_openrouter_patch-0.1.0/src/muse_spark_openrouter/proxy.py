"""Small, dependency-free OpenRouter reverse proxy for Muse Spark."""

from __future__ import annotations

import argparse
import http.client
import json
import logging
import os
import ssl
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import urlsplit

from .rewrite import rewrite_request, rewrite_response

LOG = logging.getLogger("muse-spark-openrouter")
DEFAULT_UPSTREAM = "https://openrouter.ai"
HOP_BY_HOP_HEADERS = {
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailers",
    "transfer-encoding",
    "upgrade",
}


def _rewrite_json_bytes(body: bytes) -> tuple[bytes, dict[str, str], int]:
    if not body:
        return body, {}, 0
    payload = json.loads(body.decode("utf-8"))
    rewritten, alias_to_original = rewrite_request(payload)
    if not alias_to_original:
        return body, {}, 0
    encoded = json.dumps(rewritten, separators=(",", ":")).encode("utf-8")
    return encoded, alias_to_original, len(alias_to_original)


def _restore_json_bytes(body: bytes, alias_to_original: dict[str, str]) -> bytes:
    if not body or not alias_to_original:
        return body
    payload = json.loads(body.decode("utf-8"))
    restored = rewrite_response(payload, alias_to_original)
    return json.dumps(restored, separators=(",", ":")).encode("utf-8")


def rewrite_sse_line(line: bytes, alias_to_original: dict[str, str]) -> bytes:
    """Restore tool names inside one SSE data line."""
    if not alias_to_original or not line.startswith(b"data:"):
        return line
    prefix, _, raw = line.partition(b":")
    stripped = raw.strip()
    if not stripped or stripped == b"[DONE]":
        return line
    try:
        restored = _restore_json_bytes(stripped, alias_to_original)
    except (UnicodeDecodeError, json.JSONDecodeError):
        return line
    newline = b"\n" if line.endswith(b"\n") else b""
    return prefix + b": " + restored + newline


class MuseProxyHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "MuseSparkOpenRouterPatch/0.1"

    def log_message(self, fmt: str, *args: Any) -> None:
        LOG.info("%s - %s", self.client_address[0], fmt % args)

    @property
    def upstream(self) -> str:
        return str(getattr(self.server, "upstream", DEFAULT_UPSTREAM))

    def do_GET(self) -> None:
        if self.path.rstrip("/") == "/healthz":
            body = b'{"status":"ok"}\n'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self._proxy()

    def do_POST(self) -> None:
        self._proxy()

    def do_DELETE(self) -> None:
        self._proxy()

    def do_PUT(self) -> None:
        self._proxy()

    def _proxy(self) -> None:
        content_length = int(self.headers.get("Content-Length", "0"))
        request_body = self.rfile.read(content_length) if content_length else b""
        alias_to_original: dict[str, str] = {}
        rewritten_count = 0

        content_type = self.headers.get("Content-Type", "")
        LOG.debug(
            "incoming %s %s content_type=%r content_encoding=%r "
            "content_length=%d transfer_encoding=%r",
            self.command,
            self.path,
            content_type,
            self.headers.get("Content-Encoding"),
            content_length,
            self.headers.get("Transfer-Encoding"),
        )
        if request_body and "application/json" in content_type:
            try:
                request_body, alias_to_original, rewritten_count = _rewrite_json_bytes(
                    request_body
                )
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                self.send_error(400, f"Invalid JSON request: {exc}")
                return

        target = urlsplit(self.upstream)
        if target.scheme not in {"http", "https"} or not target.hostname:
            self.send_error(500, "Invalid upstream URL")
            return
        upstream_path = f"{target.path.rstrip('/')}{self.path}"

        headers = {
            key: value
            for key, value in self.headers.items()
            if key.lower() not in HOP_BY_HOP_HEADERS
            and key.lower() not in {"host", "content-length", "accept-encoding"}
        }
        headers["Host"] = target.netloc
        headers["Content-Length"] = str(len(request_body))
        headers["Accept-Encoding"] = "identity"
        headers.setdefault("X-Title", "Muse Spark OpenRouter Patch")

        connection_class = (
            http.client.HTTPSConnection
            if target.scheme == "https"
            else http.client.HTTPConnection
        )
        kwargs: dict[str, Any] = {"timeout": 330}
        if target.scheme == "https":
            kwargs["context"] = ssl.create_default_context()
        connection = connection_class(target.hostname, target.port, **kwargs)

        try:
            connection.request(
                self.command, upstream_path, body=request_body, headers=headers
            )
            response = connection.getresponse()
            response_content_type = response.getheader("Content-Type", "")
            is_sse = "text/event-stream" in response_content_type

            if is_sse:
                self._send_streaming_response(response, alias_to_original)
            else:
                upstream_body = response.read()
                if "application/json" in response_content_type:
                    try:
                        upstream_body = _restore_json_bytes(
                            upstream_body, alias_to_original
                        )
                    except (UnicodeDecodeError, json.JSONDecodeError):
                        pass
                self._send_buffered_response(response, upstream_body)

            if rewritten_count:
                LOG.info(
                    "rewrote %d overlong tool name(s) for %s %s -> %s",
                    rewritten_count,
                    self.command,
                    self.path,
                    response.status,
                )
        except (OSError, http.client.HTTPException) as exc:
            LOG.error("upstream request failed: %s", exc)
            self.send_error(502, "OpenRouter upstream request failed")
        finally:
            connection.close()

    def _copy_response_headers(
        self, response: http.client.HTTPResponse, *, content_length: int | None
    ) -> None:
        for key, value in response.getheaders():
            lower = key.lower()
            if lower in HOP_BY_HOP_HEADERS or lower in {
                "content-length",
                "content-encoding",
            }:
                continue
            self.send_header(key, value)
        if content_length is not None:
            self.send_header("Content-Length", str(content_length))
        else:
            self.send_header("Connection", "close")
            self.close_connection = True

    def _send_buffered_response(
        self, response: http.client.HTTPResponse, body: bytes
    ) -> None:
        self.send_response(response.status, response.reason)
        self._copy_response_headers(response, content_length=len(body))
        self.end_headers()
        if body:
            self.wfile.write(body)

    def _send_streaming_response(
        self,
        response: http.client.HTTPResponse,
        alias_to_original: dict[str, str],
    ) -> None:
        self.send_response(response.status, response.reason)
        self._copy_response_headers(response, content_length=None)
        self.end_headers()
        while True:
            line = response.readline()
            if not line:
                break
            self.wfile.write(rewrite_sse_line(line, alias_to_original))
            self.wfile.flush()


class MuseProxyServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address: tuple[str, int], upstream: str):
        super().__init__(address, MuseProxyHandler)
        self.upstream = upstream


def serve(host: str, port: int, upstream: str = DEFAULT_UPSTREAM) -> None:
    server = MuseProxyServer((host, port), upstream.rstrip("/"))
    LOG.info("listening on http://%s:%d; upstream=%s", host, port, upstream)
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


def proxy_main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--host", default=os.environ.get("MUSE_SPARK_PROXY_HOST", "127.0.0.1")
    )
    parser.add_argument(
        "--port", type=int, default=int(os.environ.get("MUSE_SPARK_PROXY_PORT", "8787"))
    )
    parser.add_argument(
        "--upstream", default=os.environ.get("MUSE_SPARK_UPSTREAM", DEFAULT_UPSTREAM)
    )
    parser.add_argument(
        "--log-level", default=os.environ.get("MUSE_SPARK_LOG_LEVEL", "INFO")
    )
    args = parser.parse_args(argv)
    logging.basicConfig(
        level=args.log_level.upper(), format="%(asctime)s %(levelname)s %(message)s"
    )
    serve(args.host, args.port, args.upstream)
