"""Command-line interface for the Muse Spark OpenRouter patch."""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import time

from . import __version__
from .install import (
    DEFAULT_MODEL,
    DEFAULT_PORT,
    doctor,
    healthcheck,
    read_credential,
    setup,
    start_service,
)
from .proxy import proxy_main


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="muse-spark-openrouter")
    parser.add_argument("--version", action="version", version=__version__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    serve_parser = subparsers.add_parser("serve", help="run the compatibility proxy")
    serve_parser.add_argument(
        "--host", default=os.environ.get("MUSE_SPARK_PROXY_HOST", "127.0.0.1")
    )
    serve_parser.add_argument(
        "--port",
        type=int,
        default=int(os.environ.get("MUSE_SPARK_PROXY_PORT", DEFAULT_PORT)),
    )
    serve_parser.add_argument(
        "--upstream",
        default=os.environ.get("MUSE_SPARK_UPSTREAM", "https://openrouter.ai"),
    )
    serve_parser.add_argument(
        "--log-level", default=os.environ.get("MUSE_SPARK_LOG_LEVEL", "INFO")
    )

    setup_parser = subparsers.add_parser(
        "setup", help="store the key and configure Codex"
    )
    setup_parser.add_argument(
        "--key-stdin",
        action="store_true",
        help="read the key from stdin without echoing it",
    )
    setup_parser.add_argument(
        "--no-validate",
        action="store_true",
        help="skip OpenRouter credential validation",
    )
    setup_parser.add_argument(
        "--no-systemd",
        action="store_true",
        help="use a detached process instead of systemd",
    )
    setup_parser.add_argument(
        "--set-default",
        action="store_true",
        help="make Muse Spark the default Codex model",
    )
    setup_parser.add_argument("--model", default=DEFAULT_MODEL)
    setup_parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    setup_parser.add_argument(
        "--no-patch-shell",
        action="store_true",
        help="do not replace a legacy key export in .bashrc",
    )

    credential_parser = subparsers.add_parser(
        "credential", help="print the key for Codex auth.command"
    )
    credential_parser.set_defaults(credential=True)

    doctor_parser = subparsers.add_parser(
        "doctor", help="check credentials, proxy, and Codex profile"
    )
    doctor_parser.add_argument(
        "--live", action="store_true", help="send a small paid Muse Spark request"
    )
    doctor_parser.add_argument("--model", default=DEFAULT_MODEL)
    doctor_parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _parser()
    args = parser.parse_args(argv)
    try:
        if args.command == "serve":
            proxy_main(
                [
                    "--host",
                    args.host,
                    "--port",
                    str(args.port),
                    "--upstream",
                    args.upstream,
                    "--log-level",
                    args.log_level,
                ]
            )
            return 0
        if args.command == "setup":
            setup(
                key_stdin=args.key_stdin,
                no_validate=args.no_validate,
                no_systemd=args.no_systemd,
                set_default=args.set_default,
                model=args.model,
                port=args.port,
                patch_shell=not args.no_patch_shell,
            )
            return 0
        if args.command == "credential":
            print(read_credential())
            return 0
        if args.command == "doctor":
            return doctor(args.port, live=args.live, model=args.model)
    except (OSError, RuntimeError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    parser.error("unknown command")
    return 2


def codex_main() -> int:
    port = int(os.environ.get("MUSE_SPARK_PROXY_PORT", DEFAULT_PORT))
    if not healthcheck(port):
        start_service(port)
        for _ in range(30):
            if healthcheck(port):
                break
            time.sleep(0.1)
    if not healthcheck(port):
        print("error: Muse Spark proxy did not start", file=sys.stderr)
        return 1

    codex = os.environ.get("CODEX_BIN") or shutil.which("codex")
    if not codex:
        print(
            "error: codex executable not found in PATH; set CODEX_BIN", file=sys.stderr
        )
        return 1
    command = [codex, "--profile", "muse-spark", *sys.argv[1:]]
    return subprocess.call(command)


if __name__ == "__main__":
    raise SystemExit(main())
