import json
import unittest

from muse_spark_openrouter.proxy import rewrite_sse_line
from muse_spark_openrouter.rewrite import (
    MAX_TOOL_NAME_LENGTH,
    alias_tool_name,
    rewrite_request,
    rewrite_response,
)


class ToolNameRewriteTests(unittest.TestCase):
    def test_short_name_is_unchanged(self):
        self.assertEqual(alias_tool_name("shell"), "shell")

    def test_long_name_is_deterministic_and_bounded(self):
        name = "mcp__server__" + "long_tool_" * 10
        first = alias_tool_name(name)
        second = alias_tool_name(name)
        self.assertEqual(first, second)
        self.assertEqual(len(first), MAX_TOOL_NAME_LENGTH)
        self.assertNotEqual(first, name)

    def test_request_and_response_round_trip(self):
        name = "mcp__cloudflare__" + "very_long_tool_name_" * 4
        request = {
            "model": "meta/muse-spark-1.2",
            "tools": [
                {"type": "function", "name": name, "parameters": {"type": "object"}}
            ],
            "tool_choice": {"type": "function", "name": name},
        }
        rewritten, reverse = rewrite_request(request)
        alias = rewritten["tools"][0]["name"]
        self.assertLessEqual(len(alias), 64)
        self.assertEqual(rewritten["tool_choice"]["name"], alias)
        self.assertEqual(request["tools"][0]["name"], name)

        response = {
            "output": [{"type": "function_call", "name": alias, "arguments": "{}"}]
        }
        restored = rewrite_response(response, reverse)
        self.assertEqual(restored["output"][0]["name"], name)

    def test_nested_tool_name_is_rewritten(self):
        namespace = "namespace_of_length_22x"
        self.assertEqual(len(namespace), 23)
        name = "inner_tool_name_that_is_exactly_forty_two_"
        self.assertEqual(len(name), 42)
        request = {
            "tools": [
                {
                    "type": "namespace",
                    "name": namespace,
                    "tools": [
                        {
                            "type": "function",
                            "name": name,
                            "parameters": {},
                        }
                    ],
                }
            ]
        }
        rewritten, reverse = rewrite_request(request)
        alias = rewritten["tools"][0]["tools"][0]["name"]
        self.assertLessEqual(len(namespace) + 2 + len(alias), 64)
        self.assertEqual(reverse[alias], name)

    def test_sse_response_restores_name(self):
        original = "mcp__server__" + "x" * 80
        alias = alias_tool_name(original)
        event = {
            "type": "response.output_item.added",
            "item": {"type": "function_call", "name": alias},
        }
        line = b"data: " + json.dumps(event).encode() + b"\n"
        restored = rewrite_sse_line(line, {alias: original})
        payload = json.loads(restored.removeprefix(b"data: "))
        self.assertEqual(payload["item"]["name"], original)


if __name__ == "__main__":
    unittest.main()
