"""Muse Spark compatibility support for Codex and OpenRouter."""

__version__ = "0.1.0"
